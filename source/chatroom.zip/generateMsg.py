# -*- coding: cp936 -*-
import MySQLdb
import time
from random import Random
import random

#��������û������¼
def msg_generate():
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select name from name_pwd")
    user_list = cur.fetchall()

    # user combine
    double_list=[]
    for user in user_list:
        for user2 in user_list:
            if user!=user2:
                double_list.append([user,user2])
    #print double_list 

    # give msg
    msg_list=[]
    for item in double_list:
        temp = rand_time()
        msg_list.append([item[0],item[1],random_str(),temp[0],temp[1]])

    for item in msg_list:
        #print item[0],item[1],item[2],item[3]
        # �������ݿ�
        cur.execute("insert into msg values('%s','%s','%s','%s','%d')"%(item[0][0],item[1][0],item[2],item[3],item[4]))
    user_list = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()


#��������û������¼���ݣ�����Ϊ20
def random_str(randomlength=20):
    str = ''
    chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789'
    length = len(chars) - 1
    random = Random()
    for i in range(randomlength):
        str+=chars[random.randint(0, length)]
    return str

a1=(2000,1,1,0,0,0,0,0,0)  #2000-01-01 00:00:00
a2=(2017,12,12,23,59,59,0,0,0)    #2017-11-26 23:59:59

start=time.mktime(a1)    
end=time.mktime(a2)     

#�������һ����2000-01-01 00:00:00��2017-11-26 23:59:59��ʱ���
def rand_time():      
    t=random.randint(start,end)  
    date_touple=time.localtime(t)        
    date=time.strftime("%a %b %d %H:%M:%S %Y",date_touple)
    return date,t

if __name__=='__main__':
    for i in range(10):
        msg_generate()
