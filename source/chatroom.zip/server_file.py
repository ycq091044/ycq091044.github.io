# -*- coding: cp936 -*-
from socketserver import BaseRequestHandler,ThreadingTCPServer
import threading
from getTool import sendMsg
import MySQLdb
import time
import struct
import os
from PIL import Image
# buffer
BUF_SIZE=1024

#���̷߳������࣬�׽��ִ���
class Handler(BaseRequestHandler):
        
        #�û��б�
	conn_list ={}
	time_out = 1
	def setup(self):
		self.conn_list[self.client_address] = self
				
	def handle(self):

                #���������Ϣ
		address,pid = self.client_address
		print '-----------------------------'
		print u"connect...",address,pid
		addr = (address,pid)
		t = 0
		while True:

                        #����ѭ�������Խ��ܣ������ļ��򱣴沢ת��
			time.sleep(0.1)
			try:
				fhead = self.request.recv(FILEINFO_SIZE)
				filename,temp1,filesize,temp2=struct.unpack('128s32sI8s',fhead)
				print filename
				print u'filesize:',filesize
				filename='static/uploads/new_'+getlast(filename.strip('\00'))
				fp=open(filename,'wb')
				restsize = filesize
				print u"receiving..\n"
				while True:

                                        #ÿ�δ��䳤��Ϊһ��buffer
					if restsize >BUF_SIZE:
						filedata = self.request.recv(BUF_SIZE)
					else:
						filedata = self.request.recv(restsize)
					if not filedata:
						break
					fp.write(filedata)
					restsize=restsize-len(filedata)
					if restsize==0:
						break
				print u'receive over...\n'
				print '---------------'
				fp.close()
				changesize(filename)
				print u'broadcast'
				print filename
				if t!=0:
					self.broadcast(filename)
			except:
				pass
			t = t+1
	#ת���������û�
	def broadcast(self,filename):
		fhead=struct.pack('128s11I',filename,0,0,0,0,0,0,0,0,os.stat(filename).st_size,0,0)
		for item in self.conn_list.keys():
			print 'user',item,'\n'
			self.conn_list[item].request.sendall(fhead)
			fp = open(filename,'rb')
			while 1:
				filedata = fp.read(BUF_SIZE)
				if not filedata:
					break
				self.conn_list[item].request.sendall(filedata)
			fp.close()

#�õ���׺��			
def getlast(s):
	temp = s.split('/')[-1]
	return temp			

#ת��ͷ��size
def changesize(uri):
	try:
		im = Image.open(uri)
		print im.size
		im2 = im.resize((64,64))
		im2.save(uri)
	except:
		pass

if __name__=='__main__':
	HOST = '127.0.0.1'
	PORT = 8000
	ADDR = (HOST,PORT)
	FILEINFO_SIZE=struct.calcsize('128s32sI8s')
	server = ThreadingTCPServer(ADDR,Handler)
	print('file listening')
	server.serve_forever()
	print(server)
