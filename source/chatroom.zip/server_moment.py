# -*- coding: cp936 -*-
import os
from flask import Flask,render_template
from flask import request
import MySQLdb
import hashlib
from PIL import Image
from os import path
import MySQLdb
import time
from random import Random
import random

#initial
app = Flask(__name__)
@app.route('/', methods=['GET'])
def index():
	return render_template('index.html')

# when register
@app.route('/register', methods=['POST'])
def register():
    # get register information
    name_reg=request.form['name_reg']
    pwd_reg=request.form['pwd_reg']
    pwd2_reg=request.form['pwd2_reg']
    mail_reg=request.form['mail_reg']
    # if the name exists ?
    exist = if_name_exist(name_reg)

    # if information is OK
    if pwd_reg==pwd2_reg and len(name_reg)>5 and len(pwd_reg)>5 :
        # if the name exists
        if exist :
            return render_template('index.html',tips='This name has already been registered')
        # if the it's a new name
        else:
    	   add_user(name_reg,pwd_reg,mail_reg)
    	   return render_template('index2.html',name=name_reg,nickname=name_reg)
    # the information has something wrong
    else:
    	return render_template('index.html')

# when login in
@app.route('/login', methods=['POST'])
def login():
    # get the login information
    name_login=request.form['name_login']
    pwd_login=request.form['pwd_login']
    # query form sql to get the profile
    nickname,profession,motto,image,judge = showProfile(name_login)
    # if it's a correct user
    if name_exist(name_login):
        # if the pwd is also correct
    	if name_pwd(name_login,pwd_login):
            # if the user alreadly has profile
            if judge==1:
    		    return render_template('index2.html',image=image,name=name_login,nickname=nickname,profession=profession,motto=motto,activity=get_activity(),person=person(name_login))
            # no information
            else:
                return render_template('index2.html',name=name_login,nickname=name_login)
    	# wrong pwd
        else:
    		return render_template('index.html',tips='the password is incorrect!')
    # no such user
    else:
    	return render_template('index.html',tips='name is not exists!')

@app.route('/updateProfile', methods=['POST'])
def update():
    # get new image
    image = request.files['image']
    base_path = path.abspath(path.dirname(__file__))
    upload_path = path.join(base_path,'static/uploads/')
    # use hash_md5 to give a unique uri
    hash_md5 = hashlib.md5(image.filename)
    image_name = upload_path +hash_md5.hexdigest()+ image.filename
    #save image
    if image.filename!='':
        image.save(image_name)
    # get the new profile
    name=request.form['name']
    nickname=request.form['nickname']
    profession=request.form['profession']
    motto=request.form['motto']
    # profile is ok
    if nickname!='' and profession!='' and len(motto)>6 and image.filename!='':
        # update the profile
        updateProfile(name,nickname,profession,motto,hash_md5.hexdigest()+image.filename)
        # return with new profile
        return render_template('index2.html',image='static/uploads/'+hash_md5.hexdigest()+image.filename,name=name,nickname=nickname,profession=profession,motto=motto,activity=get_activity(),person=person(name))
    # profile has something wrong
    else:
        # get old profile
        nickname,profession,motto,image,judge = showProfile(name)
        # is yes
        if judge==1:
            return render_template('index2.html',image=image,name=name,nickname=nickname,profession=profession,motto=motto,activity=get_activity(),person=person(name))
        # if no
        else:
            return render_template('index2.html',name=name,nickname=name,profession=profession,motto=motto,activity=get_activity(),person=person(name))

@app.route('/sendMoment', methods=['POST'])
def sendMoment():
    # get info
    name = request.form['name']
    nickname=request.form['nickname']
    mood=request.form['mood']
    content=request.form['content']
    location=request.form['location']
    # profile is ok
    if nickname!='' and mood!='' and len(content)>6 and location!='':
        # update the profile
        sendmoment(name,nickname,mood,content,location)
        # return with new profile
        nickname,profession,motto,image,judge = showProfile(name)
        return render_template('index2.html',image=image,name=name,nickname=nickname,profession=profession,motto=motto,activity=get_activity(),person=person(name))
    else:
        return render_template('index2.html',image=image,name=name,nickname=nickname,profession=profession,motto=motto,activity=get_activity(),person=person(name))
    

#��ѯ�û����������
def check(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s' " %(name))
    cur.close()
    conn.commit()
    conn.close()
    return n

#����һ�����û�
def add_user(name,pwd,motto,img):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    if check(name) :
        cur.close()
        conn.commit()
        conn.close()
        return 0
    else:
        cur.execute("insert into name_pwd values('%s','%s','%s','%s','Undergraduate in SJTU','Mr.Box')" %(name,pwd,motto,img))
        cur.close()
        conn.commit()
        conn.close()
        return 1

#�����û��ĸ�����Ϣ
def updateProfile(name,nickname,profession,motto,image):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name='%s'" %(name))
    data = cur.fetchall()[0]
    pwd = data[1]
    cur.execute("delete from name_pwd where name='%s'" %(name))
    cur.execute("insert into name_pwd values('%s','%s','static/uploads/%s','%s','%s','%s')" %(name,pwd,image,motto,profession,nickname))
    cur.close()
    conn.commit()
    conn.close()

#������Ϣ
def sendMsg(receiver,sender,txt):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("insert into msg values('%s','%s','%s','%s','%s')" %(receiver,sender,txt,time.ctime(),time.time()))
    cur.close()
    conn.commit()
    conn.close()

#�ж��û����������
def if_name_exist(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s'" %(name))
    cur.close()
    conn.commit()
    conn.close()
    return n

#�õ��û��ĸ�����Ϣ
def showProfile(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name='%s'" %(name))
    try:
        data = cur.fetchall()[0]
        nickname = data[5]
        profession = data[4]
        motto = data[3]
        image_path = data[2]
        judge = 1
    except:
        nickname = ''
        profession = ''
        motto = ''
        image_path = ''
        judge = 0
    cur.close()
    conn.commit()
    conn.close()
    return nickname,profession,motto,image_path,judge

#���Ͷ�̬Ȧ
def sendmoment(name,nickname,mood,content,location):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("insert into activity_log values('%s','%s','%s','%s','%s','%s','%d')" %(name,nickname,content,time.ctime(),location,mood,time.time()))
    cur.close()
    conn.commit()
    conn.close()

#�ҵ�ͷ��img
def self_head(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name ='%s'"%(name))
    data = cur.fetchall()[0]
    cur.close()
    conn.commit()
    conn.close()
    return data[2]

#��ѯ���еĶ�̬
def get_activity():
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select name,nickname,log,time,location,mood from activity_log order by time2 desc")
    activity = cur.fetchall()
    
    cur.close()
    conn.commit()
    conn.close()
    return activity

#�ҵ������˵�������Ϣ��չ������ҳ��
def person(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select name,img,nickname,motto from name_pwd where name!='%s'"%(name))
    user_list = cur.fetchall()

    all_list1=[]
    for i in user_list:
        if i[0]!='group' and i[0]!='yangchaoqi':
            cur.execute("select * from username_address where name='%s'"%(i[0]))
            n = cur.fetchall()[0][3]
            if n==0:
                n='frontend'
            else:
                n='backend'
        elif i[0]!='yangchaoqi':
            n = 'backend'
        else:
            n = 'frontend'
        print i[0],n
        temp=[i[0],n,i[1],i[3],i[2],get_msg(name,i[0])]
        if len(temp[3])>20:
            temp[3] = temp[3][:20]
        all_list1.append(temp)
    cur.close()
    conn.commit()
    conn.close()
    return all_list1

#�õ������¼
def get_msg(name1,name2):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select message,time,time2 from msg where receiver='%s' and sender='%s'"%(name1,name2))
    data1 = cur.fetchall()
    cur.execute("select message,time,time2 from msg where receiver='%s' and sender='%s'"%(name2,name1))
    data2 = cur.fetchall()

    total_list=[]
    for item in data1:
        total_list.append(['left',get_img(name2),name2,item[0],item[1],item[2],''])
    for item in data2:
        total_list.append(['right',get_img(name1),name1,item[0],item[1],item[2],'speech-right'])
    total_list = sorted(total_list,key=lambda x:x[5])
    cur.close()
    conn.commit()
    conn.close()
    return total_list

#��ѯͷ��img
def get_img(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select img from name_pwd where name='%s'"%(name))
    n = cur.fetchall()[0][0]
    cur.close()
    conn.commit()
    conn.close()
    return n

#�ж��û����������
def name_exist(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s'"%(name))
    cur.close()
    conn.commit()
    conn.close()
    return n

#�ж�������ȷ��
def name_pwd(name,pwd):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s' and pwd='%s'"%(name,pwd))
    cur.close()
    conn.commit()
    conn.close()
    return n

#�ҵ������û�
def find_user(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name !='%s' and name !='group' " %(name))
    data = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    list = []
    for item in data:
        conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
        cur = conn.cursor()
        n = cur.execute("select * from username_address where name ='%s' and status=1 " %(item[0]))
        cur.close()
        conn.commit()
        conn.close()
        if n==1:
            list.append(item)
    return list

#�����û���Ϣ
def update_user(name,time_span):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name !='%s' and name !='group' " %(name))
    data = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    list = []
    for item in data:
        conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
        cur = conn.cursor()
        n = cur.execute("select * from username_address where name ='%s' and status=1 and time>'%s' " %(item[0],time_span))
        cur.close()
        conn.commit()
        conn.close()
        if n==1:
            list.append(item)
        conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
        cur = conn.cursor()
        cur.execute("select max(time) from username_address where status=1")
        t = cur.fetchall()[0][0]
        cur.close()
        conn.commit()
        conn.close()
    return list,t

#�ҵ�Ⱥ
def find_group(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name ='group'")
    data = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    return data

#��ʼ
app.run(host='127.0.0.1',port=4000,debug=True)

