# -*- coding: cp936 -*-
import os,sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from math import *

DEFAULT_HEAD = 'icons/icon.png'
DEFAULT_MSG = 'Hello world!'
DEFAULT_IMG = 'icons/img.png'

#English or not
def checkContainChinese(s):
    for ch in s.decode('utf-8',errors = 'ignore'):
        if u'\u4e00' <= ch <= u'\u9fff':
            return True
    return False

def splitStringByLen(text,Len):
    reload(sys)
    sys.setdefaultencoding('utf-8')
    #text = text.replace('\n','.')
    (myText, nLen) = ('',0)
    for s in text.decode('utf-8',errors = 'ignore'):
        myText += s
        nLen += 1.9 if checkContainChinese(s) else 1
        if nLen >= (Len - 1):
            myText += '\n'
            nLen = 0
    return myText

# head�࣬ͷ��
class LabelHead(QLabel):
    def __init__(self,addr = DEFAULT_HEAD):
        super(LabelHead,self).__init__()
        self.setScaledContents(True)
        self.setReadOnly(True)
        self.setPicture(addr)

    def setReadOnly(self,b):
        self._readOnly = bool(b)

    def setPicture(self,addr):
        self._picAddr = unicode(addr)
        img = QPixmap(addr)
        self.setPixmap(img)
        return True

    def getPicture(self):
        return self._picAddr

# Text��
class BubbleText(QLabel):
    border = 1 # msg by msg border
    trigon = 15 # trianger
    lineLen = 30 # character per line

    # size per msg
    minH = 2 * trigon + 2 * border
    minW = 2 * trigon + 2 * border

    def __init__(self,listItem,listView,text = DEFAULT_MSG,lr = True):
        self.listItem = listItem
        self.listView = listView
        self.text = text
        # transfer msg length
        myText = splitStringByLen(text, self.lineLen)

        super(BubbleText, self).__init__(myText)

        # font set 
        font = QFont()
        font.setFamily('Consolas')
        font.setFixedPitch(True)
        font.setPointSize(15)
        font.setBold(False)

        # set width
        self.setMinimumWidth(self.minW)
        self.setFont(font)
        self.setState(False)

        # I or you
        self.lr = lr
        # if right
        if self.lr:
            self.setContentsMargins(self.trigon*sqrt(3)/2 + 20,self.border + 20,self.border + 20,self.border + 20)
        # lf left
        else:
            self.setContentsMargins(self.border + 20,self.border + 20,self.trigon*sqrt(3)/2 + 20,self.border + 20)

    # �����ݿ�
    def paintEvent(self, e):
        size =  self.size()
        qp = QPainter()
        qp.begin(self)
        if self.lr:
            self.leftBubble(qp,size.width(),size.height())
        else:
            self.rightBubble(qp,size.width(),size.height())
        qp.end()
        super(BubbleText, self).paintEvent(e)

    #��ߵ����ݿ�
    def leftBubble(self,qp, w, h):
        qp.setPen(self.colorLeftE)
        qp.setBrush(self.colorLeftM)
        middle = h/2
        shifty = self.trigon/2
        shiftx = self.trigon*sqrt(3)/2
        pL = QPolygonF()
        pL.append(QPointF(0,middle)) # point 1
        pL.append(QPointF(shiftx, middle + shifty)) # point 2
        pL.append(QPointF(shiftx, h - self.border)) # point 3
        pL.append(QPointF(w - self.border, h - self.border)) # point 4
        pL.append(QPointF(w - self.border, self.border)) # point 5
        pL.append(QPointF(shiftx, self.border)) # point 6
        pL.append(QPointF(shiftx, middle - shifty)) # point 7
        qp.drawPolygon(pL)

    #�ұߵ����ݿ�
    def rightBubble(self, qp, w, h):
        qp.setPen(self.colorRightE)
        qp.setBrush(self.colorRightM)
        middle = h/2
        shifty = self.trigon/2
        shiftx = self.trigon*sqrt(3)/2
        pL = QPolygonF()
        pL.append(QPointF(w,middle)) # point 1
        pL.append(QPointF(w - shiftx, middle + shifty)) # point 2
        pL.append(QPointF(w - shiftx, h - self.border)) # point 3
        pL.append(QPointF(self.border, h - self.border)) # point 4
        pL.append(QPointF(self.border, self.border)) # point 5
        pL.append(QPointF(w - shiftx, self.border)) # point 6
        pL.append(QPointF(w - shiftx, middle - shifty)) # point 7
        qp.drawPolygon(pL)

    # when mouse in color change
    def setState(self,mouse):
        if mouse:
            self.colorLeftM = QColor("#eaeaea")
            self.colorLeftE = QColor("#D6D6D6")
            self.colorRightM = QColor("#8FD648")
            self.colorRightE = QColor("#85AF65")
        else:
            self.colorLeftM = QColor("#fafafa")
            self.colorLeftE = QColor("#D6D6D6")
            self.colorRightM = QColor("#9FE658")
            self.colorRightE = QColor("#85AF65")
        self.update()

    # mouse in
    def enterEvent(self,e):
        self.setState(True)
    # mouse out
    def leaveEvent(self,e):
        self.setState(False)
    
    # copy and delete
    def contextMenuEvent(self,e): 
        editUser = QAction(QIcon('icons/copy.png'),u'copy',self)
        editUser.triggered.connect(self.copyText)
        delUser = QAction(QIcon('icons/delete.png'),u'delete',self)
        delUser.triggered.connect(self.delTextItem)
        menu = QMenu()
        menu.addAction(editUser)
        menu.addAction(delUser)
        menu.exec_(QCursor.pos())
        e.accept()

    # copy msg
    def copyText(self,b):
        cb = QApplication.clipboard()
        cb.setText(self.text)
    # delete mdg
    def delTextItem(self,b):
        self.listView.takeItem(self.listView.indexFromItem(self.listItem).row())

# text list��
class TextItem(QWidget):
    def __init__(self, listItem, listView, text = DEFAULT_MSG, lr=True, head = DEFAULT_HEAD):
        super(TextItem,self).__init__()
        hbox = QHBoxLayout()
        text = BubbleText(listItem,listView,text,lr)
        head = LabelHead(head)
        head.setFixedSize(60,60)

        if lr is not True:
            hbox.addSpacerItem(QSpacerItem(1,1,QSizePolicy.Expanding,QSizePolicy.Preferred))
            hbox.addWidget(text)
            hbox.addWidget(head)
        else:
            hbox.addWidget(head)
            hbox.addWidget(text)
            hbox.addSpacerItem(QSpacerItem(1,1,QSizePolicy.Expanding,QSizePolicy.Preferred))
            
        hbox.setContentsMargins(20,20,0,0)
        self.setLayout(hbox)
        self.setContentsMargins(0,0,20,20)

# Image��
class BubbleImage(QLabel):
    border = 1
    trigon = 15
    lineLen = 30

    minH = 2 * trigon + 2 * border
    minW = 2 * trigon + 2 * border

    #ͼ����̳�
    def __init__(self,listItem,listView,img = DEFAULT_IMG,lr = True,maxWidth = 500):

        #��������
        self.listItem = listItem
        self.listView = listView
        self.img = img
        super(BubbleImage, self).__init__()
        self.setMinimumWidth(self.minW)
        self.setState(False)
        self.lr = lr
        if self.lr:
            self.setContentsMargins(self.trigon*sqrt(3)/2 + 20,self.border + 20,self.border + 20,self.border + 20)
        else:
            self.setContentsMargins(self.border + 20,self.border + 20,self.trigon*sqrt(3)/2 + 20,self.border + 20)

        self.setScaledContents(True)
        if not os.path.exists(img):
            img = DEFAULT_IMG

        pic = QPixmap(img)
        self.wid = pic.size().width() if pic.size().width()<maxWidth else maxWidth
        nPic = pic.scaledToWidth(self.wid) 
        self.setPixmap(nPic)

        if img.endswith('gif'):
            self.movie = QMovie(self)
            self.movie.setFileName(img)
            self.movie.setCacheMode(QMovie.CacheNone)
            self.movie.frameChanged.connect(self.animate)
            self.movie.start()

    #�źŲ۽���
    @pyqtSlot(int)
    def animate(self,index):
        pic = self.movie.currentPixmap()
        nPic = pic.scaledToWidth(self.wid)
        self.setPixmap(nPic)

    #�����ݿ�
    def paintEvent(self, e):
        size =  self.size()
        qp = QPainter()
        qp.begin(self)
        if self.lr:
            self.leftBubble(qp,size.width(),size.height())
        else:
            self.rightBubble(qp,size.width(),size.height())
        qp.end()
        super(BubbleImage, self).paintEvent(e)

    #�����ݿ�
    def leftBubble(self,qp, w, h):
        qp.setPen(self.colorLeftE)
        qp.setBrush(self.colorLeftM)
        middle = h/2
        shifty = self.trigon/2
        shiftx = self.trigon*sqrt(3)/2
        pL = QPolygonF()
        pL.append(QPointF(0,middle)) # point 1
        pL.append(QPointF(shiftx, middle + shifty)) # point 2
        pL.append(QPointF(shiftx, h - self.border)) # point 3
        pL.append(QPointF(w - self.border, h - self.border)) # point 4
        pL.append(QPointF(w - self.border, self.border)) # point 5
        pL.append(QPointF(shiftx, self.border)) # point 6
        pL.append(QPointF(shiftx, middle - shifty)) # point 7
        qp.drawPolygon(pL)

    #�����ݿ�
    def rightBubble(self, qp, w, h):
        qp.setPen(self.colorRightE)
        qp.setBrush(self.colorRightM)
        middle = h/2
        shifty = self.trigon/2
        shiftx = self.trigon*sqrt(3)/2
        pL = QPolygonF()
        pL.append(QPointF(w,middle)) # point 1
        pL.append(QPointF(w - shiftx, middle + shifty)) # point 2
        pL.append(QPointF(w - shiftx, h - self.border)) # point 3
        pL.append(QPointF(self.border, h - self.border)) # point 4
        pL.append(QPointF(self.border, self.border)) # point 5
        pL.append(QPointF(w - shiftx, self.border)) # point 6
        pL.append(QPointF(w - shiftx, middle - shifty)) # point 7
        qp.drawPolygon(pL)

    # when mouse in color change
    def setState(self,mouse):
        if mouse:
            self.colorLeftM = QColor("#eaeaea")
            self.colorLeftE = QColor("#D6D6D6")
            self.colorRightM = QColor("#8FD648")
            self.colorRightE = QColor("#85AF65")
        else:
            self.colorLeftM = QColor("#fafafa")
            self.colorLeftE = QColor("#D6D6D6")
            self.colorRightM = QColor("#9FE658")
            self.colorRightE = QColor("#85AF65")
        self.update()

    # mouse in
    def enterEvent(self,e):
        self.setState(True)
    # mouse out
    def leaveEvent(self,e):
        self.setState(False)

    #�Ҽ��˵�ʵ���ı��ĸ��ƺͿؼ���ɾ��
    def contextMenuEvent(self,e): 
        editUser = QAction(QIcon('icons/copy.png'),u'����',self)
        editUser.triggered.connect(self.copyImage)

        delUser = QAction(QIcon('icons/delete.png'),u'ɾ��',self)
        delUser.triggered.connect(self.delTextItem)

        menu = QMenu()
        menu.addAction(editUser)
        menu.addAction(delUser)
        menu.exec_(QCursor.pos())

        e.accept()
        
    def copyImage(self,b):
        cb = QApplication.clipboard()
        cb.setImage(QImage(self.img))
        
    def delTextItem(self,b):
        self.listView.takeItem(self.listView.indexFromItem(self.listItem).row())

    def mouseDoubleClickEvent(self,e):
        from PIL import Image
        im = Image.open(self.img)
        im.show()

# Image list��
class ImageItem(QWidget):
    def __init__(self, listItem, listView, img = DEFAULT_MSG, lr=True, head = DEFAULT_HEAD):
        super(ImageItem,self).__init__()
        hbox = QHBoxLayout()
        img = BubbleImage(listItem,listView,img,lr)
        head = LabelHead(head)
        head.setFixedSize(60,60)

        if lr is not True:
            hbox.addSpacerItem(QSpacerItem(1,1,QSizePolicy.Expanding,QSizePolicy.Preferred))
            hbox.addWidget(img)
            hbox.addWidget(head)
        else:
            hbox.addWidget(head)
            hbox.addWidget(img)
            hbox.addSpacerItem(QSpacerItem(1,1,QSizePolicy.Expanding,QSizePolicy.Preferred))
            
        hbox.setContentsMargins(20,20,0,0)
        self.setLayout(hbox)
        self.setContentsMargins(0,0,20,20)


# Msglist��
class MsgList(QListWidget):
    def __init__(self,head):
        super(MsgList, self).__init__()
        self.setStyleSheet(
            "QListWidget::item{border:0px solid gray;background-color:transparent;padding:0px;color:transparent}"  
            "QListView::item:!enabled{background-color:transparent;color:transparent;border:0px solid gray;padding:0px 0px 0px 0px;}"  
            "QListWidget::item:hover{background-color:transparent;color:transparent;border:0px solid gray;padding:0px 0px 0px 0px;}"  
            "QListWidget::item:selected{background-color:transparent;color:transparent;border:0px solid gray;padding:0px 0px 0px 0px;}")
        self.head=''
        self.setHead(head)

    #�Լ����ı�
    def addTextMsg(self,sz = DEFAULT_MSG, lr = True, head=DEFAULT_HEAD):
        head = self.head
        it = QListWidgetItem(self)
        wid = self.size().width()
        item = TextItem(it,self,sz,lr,head) 
        it.setSizeHint(item.sizeHint())
        it.setFlags(Qt.ItemIsEnabled)
        self.addItem(it)
        self.setItemWidget(it,item)
        self.setCurrentItem(it)

    #�����ı�
    def addTextMsg2(self,sz = DEFAULT_MSG, lr = True, head=DEFAULT_HEAD):
        it = QListWidgetItem(self)
        wid = self.size().width()
        item = TextItem(it,self,sz,lr,head) 
        it.setSizeHint(item.sizeHint())
        it.setFlags(Qt.ItemIsEnabled)
        self.addItem(it)
        self.setItemWidget(it,item)
        self.setCurrentItem(it)

    #����ͷ��
    def setHead(self,head):
        self.head = head

    #�Լ����ļ�
    def addFileMsg(self,img = DEFAULT_IMG, lr = True,head=DEFAULT_HEAD):
        head=self.head
        it = QListWidgetItem(self)
        wid = self.size().width()
        item = TextItem(it,self,img,lr,head) 
        it.setSizeHint(item.sizeHint())
        it.setFlags(Qt.ItemIsEnabled)
        self.addItem(it)
        self.setItemWidget(it,item)
        self.setCurrentItem(it)

    #�����ļ�
    def addFileMsg2(self,img = DEFAULT_IMG, lr = True,head=DEFAULT_HEAD):
        it = QListWidgetItem(self)
        wid = self.size().width()
        item = TextItem(it,self,img,lr,head) 
        it.setSizeHint(item.sizeHint())
        it.setFlags(Qt.ItemIsEnabled)
        self.addItem(it)
        self.setItemWidget(it,item)
        self.setCurrentItem(it)

    #�Լ�������
    def addEmojiMsg(self,img = DEFAULT_IMG, lr = True,head=DEFAULT_HEAD):
        head=self.head
        it = QListWidgetItem(self)
        wid = self.size().width()
        item = ImageItem(it,self,img,lr,head) 
        it.setSizeHint(item.sizeHint())
        it.setFlags(Qt.ItemIsEnabled)
        self.addItem(it)
        self.setItemWidget(it,item)
        self.setCurrentItem(it)

    #���ձ���
    def addEmojiMsg2(self,img = DEFAULT_IMG, lr = True,head=DEFAULT_HEAD):
        it = QListWidgetItem(self)
        wid = self.size().width()
        item = ImageItem(it,self,img,lr,head) 
        it.setSizeHint(item.sizeHint())
        it.setFlags(Qt.ItemIsEnabled)
        self.addItem(it)
        self.setItemWidget(it,item)
        self.setCurrentItem(it)




if __name__=='__main__':
    app = QApplication(sys.argv)
    ml=MsgList(DEFAULT_MSG)
    ml.setMinimumSize(1000,1000)
    ml.addTextMsg("Hello",True)
    ml.addTextMsg("World!",False)
    ml.show()
    sys.exit(app.exec_())