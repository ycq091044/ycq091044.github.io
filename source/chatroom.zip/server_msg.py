# -*- coding: cp936 -*-
from socketserver import BaseRequestHandler,ThreadingTCPServer
import threading
from getTool import sendMsg
import MySQLdb
import time
# buffer
BUF_SIZE=1024

#���߳�socket��
class Handler(BaseRequestHandler):

        #�û��б�
	conn_list ={}
	time_out = 1
	def setup(self):
		self.conn_list[self.client_address] = self
	def update(self):
		for item in self.conn_list.keys():

                        #�������͡�*����ȷ���û�����״̬����ʵʱ��״̬�������ݿ�
			try:
				self.conn_list[item].request.sendall('*')
			except:
				conn= MySQLdb.connect(
				host='localhost',
				user='root',
				db ='ss',
				charset='utf8'
				)
				cur = conn.cursor()
				# if now active and initial no-active
				cur.execute("update username_address set status=0  where address='%s' and pid='%s'"%(str(item[0]),str(item[1])))
				cur.close()
				conn.commit()
				conn.close()
				
	def handle(self):
		# connect
		address,pid = self.client_address
		# get username
		username = self.request.recv(BUF_SIZE)
		# insert into sql
		insert_name_address(username,address,pid)
		print '%s %d connected!'%(address,pid)
		while True:
			time.sleep(1)
			try:
				data = self.request.recv(BUF_SIZE)
			except:
				data=''

			#�յ���Ϣ����ѯreceiver��������
			if len(data)>0 :
				print 'receive',data
				receiver,sender,txt = insert(data)
				img = findimg(sender)
				if receiver=='group':
					for item in self.conn_list.keys():
						try:
							self.conn_list[item].request.sendall(sender+'_group#####'+txt+'#####'+img)
						except:
							pass
				elif receiver!='':
					temp = findReceiver(receiver)
					#print temp
					try:
						self.conn_list[temp].request.sendall(sender+'#####'+txt+'#####'+img)
					except:
						pass

			self.update()



#����������Ϣ
def insert(string):
    temp = string.split('#####')
    sendMsg(temp[0],temp[1],temp[2])
    print temp[0],temp[1],temp[2]
    return temp[0],temp[1],temp[2]

#�ҵ������ߵ�id
def findReceiver(receiver):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from username_address where name='%s'" %(receiver))
    temp = cur.fetchall()[0]
    address,pid=temp[1],temp[2]
    cur.close()
    conn.commit()
    conn.close()
    print address,pid,'1'
    return (str(address),int(pid))

#�õ������ߵ�img
def findimg(sender):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name='%s'" %(sender))
    temp = cur.fetchall()[0]
    img = temp[2]
    cur.close()
    conn.commit()
    conn.close()
    print img
    return img

#�����û�������״̬
def insert_name_address(username,address,pid):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("delete from username_address where name='%s'"%(username))
    cur.execute("insert into username_address values('%s','%s','%s',1,'%s')"%(username,address,pid,str(time.time())))
    cur.close()
    conn.commit()
    conn.close()
    print 'insert %s success !'%username
        
        
if __name__=='__main__':
	HOST = '127.0.0.1'
	PORT = 5000
	ADDR = (HOST,PORT)
	server = ThreadingTCPServer(ADDR,Handler)
	print('listening')
	server.serve_forever()
	print(server)
