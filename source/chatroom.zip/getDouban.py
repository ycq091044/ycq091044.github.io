import urllib2
import re
from bs4 import BeautifulSoup

# �Ӹ���������ȡ���ݣ����浽crawler.txt
url = 'https://movie.douban.com/review/best/?start='
file = open('crawler.txt','w')
for i in range(1,10,1):
    request = urllib2.Request(url+str(i))
    response = urllib2.urlopen(request)
    s = response.read()
    soup = BeautifulSoup(s,'html5lib')
    for i in soup.find_all(['div'],class_='short-content'):
        i = str(i).replace('<div class="short-content">','')
        i = i.replace('</div>','')
        i = i.replace('\xe5\xb1\x95\xe5\xbc\x80','')
        file.write(i.strip())
file.close()


# ��crawler.txt��������ϴ������Ϊcleaner.txt
file = open('crawler.txt','rb')
file2 = open('cleaner.txt','w')
for i in range(100):
    item = file.readline().lstrip()
    item = item.rstrip()
    if item!='':
        if item[0:3]==' (':
            while item[0]!=')':
                item=item[1:]
            item = item[1:]
            if item[0]!='<':
                file2.write(item+'\n')
        else:
            file2.write(item+'\n')
file2.close()
file.close()

