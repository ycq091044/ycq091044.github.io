# -*- coding: cp936 -*-
import os,sys
from PyQt4 import QtGui
from PyQt4 import QtCore
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PanelList import UserList,GroupList
from msgList import MsgList
from flowLayout import FlowLayout
import time
from time import sleep
import socket 
import struct
from getTool import add_user,self_head
import math
import webbrowser
#from insertMsg import sendMsg

#DEFAULT_HEAD = 'icons/hd_1.png'

# ����������
THUMB_WIDTH = 25
THUMB_HEIGHT = 25
THUMB_MIN = 25
THUMB_MAX = 25
FILE_TYPE = ['jpg', 'jpeg', 'tif', 'bmp', 'gif','png']

# չʾ��������
class ImageWidget(QtGui.QWidget):
    prevSelected = None

    """
    Use this widget to display image.
    """
    # ��̳�
    def __init__(self):
        super(ImageWidget, self).__init__()
        self.id = 0
        self.displayText = ''
        self.version = ''
        self.status = 0
        self.path = ''
        self.showStatus = True
        self.selected = False
        self.isHightlight = False
        self.thumb = QtGui.QImage()
        self.initAttrib()

    # ��������
    def initAttrib(self):
        self.name_font = QtGui.QFont()
        self.bg_color = QtGui.QColor(50, 50, 50)
        self.hightlight = QtGui.QColor(255, 255, 255, 100)
        self.edge_size = 5
        self.pen_selected = QtGui.QPen(QtGui.QColor(255, 255, 0))
        self.pen_selected.setWidth(self.edge_size) 
        self.pen_selected.setJoinStyle(QtCore.Qt.MiterJoin)

    # �������壺��ȡ���ơ�����źŵ�
    def assetFile(self):
        return self.path + "_asset_.txt"

    def thumbFile(self):
        return self.path + "_thumb_.png"

    def informationFile(self):
        return self.path + "_information_.txt"

    def getPublishPath(self):
        current_version = self.version
        if not current_version:
            current_version = '000'
        new_version = int(string.atof(current_version)) + 1
        return '%s/%03d' % (self.path, new_version)

    def getVersionPath(self, version):
        return '%s/%s' % (self.path, version)

    def getCurrentVersionPath(self):
        return self.getVersionPath(self.version)

    def setThumb(self, thumb = None):
        if not thumb:
            thumb = self.thumbFile()
        if os.path.isfile(thumb):
            self.thumb.load(QtCore.QString(thumb))
            self.repaint()
            return True

    def paintAsThumb(self, painter):
        name_height = max(self.height() * 0.15, 20)
        name_ty = self.height() - self.edge_size * 2
        # draw background
        painter.fillRect(self.rect(), self.bg_color)
        painter.drawImage(self.rect(), self.thumb)
        # draw hightlight
        if self.isHightlight and not self.selected:
            painter.fillRect(self.rect(), self.hightlight)
        # draw name
        painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255)))
        self.name_font.setPixelSize(name_height)
        painter.setFont(self.name_font)
      
        #painter.drawText(self.edge_size, name_ty, str(self.displayText))

        if self.status:
            title_height = self.edge_size + name_height
            p1 = QtCore.QPoint(0, 0)
            p2 = QtCore.QPoint(0, title_height)
            p3 = QtCore.QPoint(title_height, 0)
            painter.setPen(QtCore.Qt.NoPen)
            painter.fillRect(0, 0, self.width(), title_height, QtGui.QColor(40, 40, 40, 40))
            if self.status == 1:
                painter.setBrush(QtGui.QBrush(QtGui.QColor(255, 0, 0)))
            elif self.status == 2:
                painter.setBrush(QtGui.QBrush(QtGui.QColor(0, 255, 0)))
            elif self.status == 3:
                painter.setBrush(QtGui.QBrush(QtGui.QColor(0, 0, 255)))
            painter.drawConvexPolygon(p1, p2, p3)

        if self.version:
            version_x = self.width() - self.edge_size - name_height * 1.5
            version_y = name_height
            painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255)))
            painter.drawText(version_x, version_y, '%s' % self.version)

        # draw selected
        if self.selected:
            painter.setPen(self.pen_selected)
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.drawRect(self.edge_size/2, self.edge_size/2,
                self.width() - self.edge_size, self.height() - self.edge_size)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        self.paintAsThumb(painter)

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.setSelected()

    def mouseDoubleClickEvent(self, event):
        self.emit(QtCore.SIGNAL('doubleClick'))

    def enterEvent(self, event):
        self.isHightlight = True
        self.repaint()

    def leaveEvent(self, event):
        self.isHightlight = False
        self.repaint()

   
    def setSelected(self):
       
        if ImageWidget.prevSelected != None:
            ImageWidget.prevSelected.selected = False
            ImageWidget.prevSelected.repaint()
        self.selected = True
        self.repaint()
        ImageWidget.prevSelected = self

        self.onWidgetClicked()
        self.emit(QtCore.SIGNAL("click"), self.id)

    # ����������code��txt
    def onWidgetClicked(self):
         #print self.displayText
         file = open('1.txt','w')
         file.write('emoji/'+self.displayText)
         file.close()

# �������е������������
class ImageContainer(QtGui.QFrame):
    
    #��̳�
    def __init__(self, widgets = None):
        super(ImageContainer, self).__init__()
        containerLayout = QtGui.QVBoxLayout()
        self.item_scrollarea = QtGui.QScrollArea()
        self.item_area = QtGui.QWidget()
        self.item_scrollarea.setWidget(self.item_area)
        containerLayout.addWidget(self.item_scrollarea)

        #��������
        self.widget_w = THUMB_WIDTH
        self.widget_h = THUMB_HEIGHT
        self.min_width = THUMB_MIN
        self.max_height = THUMB_MAX
        self.asset_space = 2
        self.auto_space = False

        self.setWindowOpacity(0.0)
        self.setLayout(containerLayout)
        self.ImageWidgetList = {}

    # ���ӱ���
    def addWidget(self, widget):
        widget.setParent(self.item_area)
        widget.resize(self.widget_w, self.widget_h)
        widget.show()
        
        self.ImageWidgetList[str(widget.id)] = widget

    def addWidgets(self, widgets):
        for widget in widgets:
            self.addWidget(widget)
        self.layout()
    # ���
    def clearAll(self):
        widgets = self.item_area.children()
        if widgets:
            for widget in widgets:
                widget.setParent(None)

        self.ImageWidgetList.clear()

    #�����Ų�
    def layout(self):
        w = self.width() - 20
        widgets = self.item_area.children()

        num_x = max(math.ceil(w / (self.widget_w + self.asset_space)), 1)  # Can do -1
        num_y = math.ceil(len(widgets) / num_x)
        self.item_area.resize(w, num_y * (self.widget_h + self.asset_space) + 50)

        main_w = self.item_area.width()
        main_h = self.item_area.height()
        num_x = max(math.ceil(main_w / (self.widget_w + self.asset_space)), 1)  # Can do -1

        x = 0
        y = 0
        for i in range(len(widgets)):
            space_x = 0
            if self.auto_space:
                space_x = (main_w - self.asset_space * 2 - num_x * (self.widget_w + self.asset_space)) / num_x
            widgets[i].move(self.asset_space * 2 + x * (self.widget_w + self.asset_space + space_x),
                self.asset_space*2 + y * (self.widget_h + self.asset_space))
            x += 1
            if x >= num_x:
                x = 0
                y += 1

    # ����ͼƬresize
    def resizeEvent(self, event):
        self.layout()

    def changeItemSize(self, mount):
        widgets = self.item_area.children()
        self.widget_w += mount
        if self.widget_w > self.max_height:
            self.widget_w = self.max_height
        elif self.widget_w < self.min_width:
            self.widget_w = self.min_width

        self.widget_h += mount
        if self.widget_h > self.max_height:
            self.widget_h = self.max_height
        elif self.widget_h < self.min_width:
            self.widget_h = self.min_width

        for a in widgets:
            a.resize(self.widget_w, self.widget_h)

        self.layout()

    def setItemSize(self, size):
        widgets = self.item_area.children()

        self.widget_w = size
        self.widget_h = size

        for a in widgets:
            a.resize(size, size)

        self.layout()

    #ѡ�񴥷��ź�
    def setSelected(self, id):
        print 'ImageContainer -> setSelected    ', id
        self.ImageWidgetList[str(id)].setSelected()

class EmoWindow(QtGui.QDialog):
    #��̳У�������̳�QDialog����Ϊ��ģ̬
    def __init__(self):
        super(EmoWindow, self).__init__()
        self.setWindowTitle("Emoji")
        self.setWindowIcon(QIcon('emoji/0x1f601.png'))
        self.resize(1100,630)
        
        #���Ͱ�ť
        open=QtGui.QPushButton('Send Emoji')
        self.connect(open,QtCore.SIGNAL('clicked()'),self.ok)    

        #��������
        self.screen = QtGui.QDesktopWidget().screenGeometry()
        self.size = self.geometry()
        self.move((self.screen.width()-self.size.width())/2, (self.screen.height()-self.size.height())/2)
        mainSpliter = QtGui.QSplitter(QtCore.Qt.Horizontal)
        self.dirModel = QtGui.QDirModel(self)
        self.dirModel.setFilter(QtCore.QDir.Dirs|QtCore.QDir.NoDotAndDotDot)
        self.dirTreeView = QtGui.QTreeView()
        self.dirTreeView.setModel(self.dirModel)
        self.dirTreeView.hideColumn(1)
        self.dirTreeView.hideColumn(2)
        self.dirTreeView.hideColumn(3)
        self.dirTreeView.selectionModel().selectionChanged.connect(self.dirTreeClicked)

        #����Ⲽ��
        mainLayout = QtGui.QVBoxLayout()
        self.imageContainer = ImageContainer(mainSpliter)
        self.imageContainer.setMinimumWidth(self.geometry().width()*0.7)
        mainSpliter.addWidget(self.imageContainer)
        mainLayout.addWidget(mainSpliter)
        mainLayout.addWidget(open)
        self.setLayout(mainLayout)
        self.dirTreeClicked()

    # Ŀ¼��ת�������
    def dirTreeClicked(self):
        self.imageContainer.clearAll() 
        pathSelected =os.getcwd()+'/emoji'     
        for item in os.listdir(pathSelected):
            if item.split('.')[-1] in FILE_TYPE:     
                try:
                    widget = ImageWidget()
                    widget.displayText = item
                    widget.setThumb(unicode(pathSelected +'/' + item))
                    self.imageContainer.addWidget(widget)
                    #print item
                except:
                    pass
    def ok(self):   
        self.setModal(False)
        self.close()

#�ı��༭
class TextEdit(QTextEdit,QObject):
    entered = pyqtSignal()
    def __init__(self, parent = None):
        super(TextEdit, self).__init__(parent)
    def keyPressEvent(self,e):
        if (e.key() == Qt.Key_Return) and (e.modifiers() == Qt.ControlModifier):
            self.entered.emit()
            self.clear()
        super(TextEdit,self).keyPressEvent(e)


#�ı�������
class MsgInput(QWidget,QObject):
    cur_name = ''
    my_name = ''
    # text & file & emoji signals
    textEntered = pyqtSignal(str)
    fileEntered = pyqtSignal(str)
    emojiEntered = pyqtSignal(str)

    def __init__(self,parent = None):
        self.up_or_not = 1
        super(MsgInput, self).__init__(parent)
        # set textEdit margin
        self.setContentsMargins(0,0,0,0)
        # button size and textEdit height
        self.btnSize = 35
        self.teditHeight = 150
        # font set 
        font = QFont()
        font.setFamily('Consolas')
        font.setFixedPitch(True)
        font.setPointSize(15)
        font.setBold(False)
        # configure textEdit
        self.textEdit = TextEdit()
        self.textEdit.setMaximumHeight(self.teditHeight)
        self.setMaximumHeight(self.teditHeight+self.btnSize)
        self.textEdit.setFont(font)
        self.textEdit.entered.connect(self.sendText)

        # Image btn
        sendFile = QPushButton()
        sendFile.setStyleSheet("QPushButton{border-image:url(icons/timg.jpg);}"
             "QPushButton:hover{border: 2px groove blue;}"
             "QPushButton:pressed{border-style: inset;}")
        sendFile.setFixedSize(self.btnSize,self.btnSize)
        sendFile.clicked.connect(self.sendFile)

        # Image btn
        sendEmoji = QPushButton()
        sendEmoji.setStyleSheet("QPushButton{border-image:url(emoji/0x1f601.png);}"
             "QPushButton:hover{border: 2px groove blue;}"
             "QPushButton:pressed{border-style: inset;}")
        sendEmoji.setFixedSize(self.btnSize,self.btnSize)
        sendEmoji.clicked.connect(self.chooseEmoji)

        # font set 

        font2 = QFont()
        font2.setFamily('Consolas')
        font2.setFixedPitch(True)
        font2.setPointSize(15)
        font2.setBold(False)
        sendTxt = QPushButton(u'Send')
        sendTxt.setFont(font2)
        sendTxt.setFixedHeight(self.btnSize)
        sendTxt.clicked.connect(self.sendText)
        # update btn
        self.upBtn = QPushButton(u' Update/Stop ')
        self.upBtn.setFont(font2)
        self.upBtn.setFixedHeight(self.btnSize)
        self.upBtn.clicked.connect(self.changeState)

        # HAC moment
        self.moment = QPushButton(u' HAC Moment ')
        self.moment.setFont(font2)
        self.moment.setFixedHeight(self.btnSize)
        self.moment.clicked.connect(self.openHAC)

        # status label
        self.labelstatus = QLabel(self)   
        self.labelstatus.setFixedHeight(30)  
        self.labelstatus.setAlignment(Qt.AlignCenter)  
        self.labelstatus.setText("  ")
        self.labelstatus.setFont(font2)
        self.pe = QPalette()  
        self.labelstatus.setAutoFillBackground(True)  
        self.pe.setColor(QPalette.Window,Qt.red)
        self.labelstatus.setPalette(self.pe)

        label2 = QLabel(self)     
        label2.setText("    File")
        label2.setFont(font2)
        label3 = QLabel(self)     
        label3.setText("   Emoji")
        label3.setFont(font2)
        label4 = QLabel(self)     
        label4.setText("       ") 
        label5 = QLabel(self)     
        label5.setText("     ")
        # text btn
        hl = FlowLayout()
        hl.addWidget(label2)
        hl.addWidget(sendFile)
        hl.addWidget(label3)
        hl.addWidget(sendEmoji)
        hl.addWidget(label4)
        hl.addWidget(self.moment)
        hl.addWidget(label5)
        hl.addWidget(self.labelstatus)
        hl.setMargin(0)
        hl.addWidget(self.upBtn) 
        hl.addWidget(sendTxt)    
        # msgInput 
        vl = QVBoxLayout()
        vl.addLayout(hl)
        vl.setMargin(0)
        vl.addWidget(self.textEdit)
        self.setLayout(vl)
        self.setMaximumWidth(950)
        self.setMinimumWidth(950)

    #�򿪶�̬Ȧ����
    def openHAC(self):
        webbrowser.open("http://127.0.0.1:4000")


    #�����б����
    def changeState(self):
        if self.up_or_not == 1:
            self.up_or_not=0
            self.pe.setColor(QPalette.Window,Qt.green)
            self.labelstatus.setPalette(self.pe)
        else:
            self.up_or_not=1
            self.pe.setColor(QPalette.Window,Qt.red)
            self.labelstatus.setPalette(self.pe)

    #�����ѡ��
    def chooseEmoji(self):
        self.emo_get=EmoWindow()
        if self.emo_get.exec_():
            self.fileEntered.emit(emoji)
        file = open('1.txt','rb')
        temp = file.read()
        self.emojiEntered.emit(temp)
        sock.sendall(unicode(self.cur_name+'#####'+self.my_name+'#####'+temp+'#####'+time.ctime()))
        file.close()

    # send Image
    def sendFile(self):
        dialog = QFileDialog(self,u'select a photo...')
        dialog.setDirectory(os.getcwd() + '/ref')
        dialog.setNameFilter(u"choose file(*.*);;")
        if dialog.exec_():
            selectFileName = unicode(dialog.selectedFiles()[0])
            self.fileEntered.emit(selectFileName)
            sock.sendall(unicode(self.cur_name+'#####'+self.my_name+'#####'+selectFileName+'#####'+time.ctime()))
            self.file_send(selectFileName)
        else:
            pass

    # send file
    def file_send(self,filename):
        uri = str(filename)
        fhead=struct.pack('128s11I',uri,0,0,0,0,0,0,0,0,os.stat(uri).st_size,0,0)
        sendSock.send(fhead)
        fp = open(uri,'rb')

        while 1:
            filedata = fp.read(BUFSIZE)
            if not filedata: 
                break
            sendSock.send(filedata)
        fp.close()

    # send Text
    def sendText(self):
        txt = self.textEdit.toPlainText()
        if len(txt)>0:
            self.textEntered.emit(txt)
            self.textEdit.setText('')
            sock.sendall(unicode(self.cur_name+'#####'+self.my_name+'#####'+txt+'#####'+time.ctime()))
            

# total panel
class PyqtChatApp(QSplitter):
    curUser = {'name':None,'motto':None,'img':None}
    group = {'name':None,'motto':None,'img':None}
    def __init__(self,nickname):
        super(PyqtChatApp, self).__init__(Qt.Horizontal)
        self.ctimer = QTimer()
        self.name = nickname
        #self.setWindowTitle('%s...'%self.name)
        self.group_name = 'group'
        # default head
        self.selfHead = self_head(self.name)
        # the Window
        #self.setWindowTitle('Have a Chat!')
        self.setWindowIcon(QIcon('icons/icon.png'))
        self.setMinimumSize(1300,800)

        # user list
        self.ursList = UserList(self.name)
        self.ursList.setMaximumWidth(350)
        self.ursList.setMinimumWidth(300)
        self.ursList.myQListWidget.itemDoubleClicked.connect(self.setChatUser)
        # group list
        self.groupList = GroupList(self.group_name)
        self.groupList.myQListWidget.itemDoubleClicked.connect(self.groupChat)

        # now chat list
        self.msgList = MsgList(self.selfHead)
        self.setContentsMargins(15,15,15,15)
        self.msgList.setDisabled(True)
        self.msgList.setMaximumWidth(1000)
        self.msgList.setMinimumWidth(950)
        self.msgInput = MsgInput()
        self.msgInput.my_name = self.name
        self.msgInput.textEntered.connect(self.sendTextMsg)
        self.msgInput.fileEntered.connect(self.sendFileMsg)
        self.msgInput.emojiEntered.connect(self.sendEmojiMsg)

        
        # splitter
        #self.ursList.setParent(self)
        rSpliter = QSplitter(Qt.Vertical, self)
        self.msgList.setParent(rSpliter)
        self.msgInput.setParent(rSpliter)
        lSpliter = QSplitter(Qt.Vertical, self)
        self.ursList.setParent(lSpliter)
        self.groupList.setParent(lSpliter)
        total = QSplitter(Qt.Horizontal,self)
        lSpliter.setParent(total)
        rSpliter.setParent(total)
        # demouser
        # self.setDemoUser()
        self.constant()
        QObject.connect(self.ctimer, SIGNAL("timeout()"), self.add)
        self.setWindowTitle('Have a Chat !')

    #ѭ��������Ϣ
    def add(self):
        try:
            recv_data= sock.recv(BUFSIZE)
        except:
            recv_data='*'
        try:
            receive_file()
        except:
            pass
        self.addMsg(recv_data)
        if self.msgInput.up_or_not == 0:
            self.ursList.update()
        
    #�Ի������Ӽ�¼
    def addMsg(self,data):
        data=getmain(data)
        if data!='':
            temp = data.split('#####')
            if temp[0][-6:]=='_group' and self.curUser['name']=='group' and temp[0][:-6]!=self.name:
                if temp[1]!='' and temp[1][-4:]=='.png':
                    self.msgList.addEmojiMsg2(temp[1],True,self_head(temp[0][:-6]))
                else:
                    self.msgList.addTextMsg2(temp[1],True,self_head(temp[0][:-6]))
            elif temp[0]==self.curUser['name']:
                if temp[1]!='' and temp[1][-4:]=='.png':
                    self.msgList.addEmojiMsg2(temp[1],True,self.curUser['img'])
                else:
                    self.msgList.addTextMsg2(temp[1],True,self.curUser['img'])

    #Qtimer��ʱ��
    def constant(self):
        self.ctimer.start(1000)

    #�����û���
    def setName(self,string_name):
        self.name = string_name
        self.ursList.name=self.name
        self.msgInput.my_name=self.name
        self.selfHead = self_head(self.name)
        self.msgList.setHead(self.selfHead)
    '''    
    def setChatMsg(self):
        self.msgList.clear()
        self.msgList.addTextMsg("Hello",True,self.curUser['img'])
        self.msgList.addTextMsg("World!",False,self.selfHead)
        self.msgList.addTextMsg("afaaffffafa...",True,self.curUser['img'])
        self.msgList.addTextMsg("With a gentle look on her face, she paused and saidafafa",False,self.selfHead)
        self.msgList.addImageMsg('ref/bq.gif',True,self.curUser['img'])
    def setGroupMsg(self):
        self.msgList.clear()
        self.msgList.addTextMsg("Hello",True,self.group['img'])
        self.msgList.addTextMsg("World!",False,self.selfHead)
        self.msgList.addTextMsg("afasfsa...",True,self.group['img'])
        self.msgList.addTextMsg("afafafa",False,self.selfHead)
        self.msgList.addImageMsg('ref/bq.gif',True,self.group['img'])
    '''
    

    #�źŴ�������
    @pyqtSlot(str)
    def sendTextMsg(self,txt):
        txt = unicode(txt)
        self.msgList.addTextMsg(txt,False)
    @pyqtSlot(str)
    def sendFileMsg(self,file):
        file = unicode(file)
        self.msgList.addFileMsg(file,False)
    @pyqtSlot(str)
    def sendEmojiMsg(self,emoji):
        emoji = unicode(emoji)
        #print emoji,1
        self.msgList.addEmojiMsg(emoji,False)

    #�������촰�ڿ���
    @pyqtSlot(QListWidgetItem)
    def setChatUser(self,item):
        self.msgList.setDisabled(False)
        temp1,temp2,temp3 = self.ursList.query(item)
        self.setWindowTitle('Now Chating with %s ......'% temp1)
        (self.curUser['name'],self.curUser['motto'],self.curUser['img']) = (temp1,temp2,temp3)
        self.msgInput.cur_name = self.curUser['name']
        #self.setChatMsg()
        self.msgList.clear()

    #Ⱥ���촰�ڿ���
    @pyqtSlot(QListWidgetItem)
    def groupChat(self,item):
        self.msgList.setDisabled(False)
        temp1,temp2,temp3 = self.groupList.query(item)
        self.setWindowTitle('Now Chating with Group ......')
        (self.group['name'],self.group['motto'],self.group['img']) = (temp1,temp2,temp3)
        (self.curUser['name'],self.curUser['motto'],self.curUser['img']) = (temp1,temp2,temp3)
        #self.setGroupMsg()
        self.msgInput.cur_name = self.group['name']
        self.msgList.clear()

#�����ֶ�
def getmain(string):
    while string and string[0]=='*':
        string = string[1:]
    while string!='' and string[-1]=='*':
        string = string[:-1]
    return string

#�õ��ļ�·��β��
def getlast(s):
    temp = s.split('/')[-1]
    return temp

#�����ļ���ӡlog
def receive_file():
    fhead = sendSock.recv(FILEINFO_SIZE)
    filename,temp1,filesize,temp2=struct.unpack('128s32sI8s',fhead)
    print filename
    print u'filesize:',filesize

    filename = 'upload1/my'+getlast(filename.strip('\00')) #...
    fp = open(filename,'wb')
    restsize = filesize
    #print restsize
    print u"receiving......... \n",

    while 1:
        if restsize > BUFSIZE:
            filedata = sendSock.recv(BUFSIZE)
            #print len(filedata)
        else:
            filedata = sendSock.recv(restsize)
        if not filedata: 
            break
        #print '1'
        fp.write(filedata)
        restsize = restsize-len(filedata)
        if restsize == 0:
            break
    print u"receive over........\n"
    print '-------------------------------'
    fp.close()




#��¼������
class Login(QtGui.QDialog):   
    def __init__(self, parent=None):   
        QtGui.QDialog.__init__(self, parent)   
        self.setWindowTitle('Have a Chat !')
        self.setWindowIcon(QIcon('icons/icon.png'))

        # font set 

        self.font = QtGui.QFont()
        self.font.setFamily('Consolas')
        self.font.setFixedPitch(True)
        self.font.setPointSize(15)
        self.font.setBold(False)

        self.font2 = QtGui.QFont()
        self.font2.setFamily('Consolas')
        self.font2.setFixedPitch(True)
        self.font2.setPointSize(20)
        self.font2.setBold(True)

        self.font3 = QtGui.QFont()
        self.font3.setFamily('Consolas')
        self.font3.setFixedPitch(True)
        self.font3.setPointSize(9)
        self.font3.setBold(False)


        self.labeltop = QtGui.QLabel(self)   
        self.labeltop.setFixedHeight(50)  
        #self.label.setAlignment(Qt.AlignCenter)  
        self.labeltop.setText("Login Form")
        self.labeltop.move(160, 20)  
        self.labeltop.setFont(self.font2)

        self.label1 = QtGui.QLabel(self)   
        self.label1.setFixedHeight(50)  
        #self.label.setAlignment(Qt.AlignCenter)  
        self.label1.setText("Username:")
        self.label1.move(50, 80)  
        self.label1.setFont(self.font)

        self.label2 = QtGui.QLabel(self)   
        self.label2.setFixedHeight(50)  
        #self.label.setAlignment(Qt.AlignCenter)  
        self.label2.setText("Password:")
        self.label2.move(50, 140)  
        self.label2.setFont(self.font)

        self.label3 = QtGui.QLabel(self)   
        self.label3.setFixedHeight(50)  
        #self.label.setAlignment(Qt.AlignCenter)  
        self.label3.setText("Motto:")
        self.label3.move(50, 200)  
        self.label3.setFont(self.font)

        self.label3 = QtGui.QLabel(self)   
        self.label3.setFixedHeight(50)  
        #self.label.setAlignment(Qt.AlignCenter)  
        self.label3.setText("Profile Photo:")
        self.label3.move(50, 260)  
        self.label3.setFont(self.font)

        self.user = QtGui.QLineEdit(self)   
        self.user.move(185, 90)  
        self.user.setMaximumWidth(280)
        self.user.setMinimumWidth(280)   
        self.user.setFont(self.font)

        self.pwd = QtGui.QLineEdit(self)   
        self.pwd.move(185, 150)   
        self.pwd.setMaximumWidth(280)
        self.pwd.setMinimumWidth(280)  
        self.pwd.setFont(self.font)
        self.pwd.setEchoMode(QtGui.QLineEdit.Password) 

        self.motto = QtGui.QLineEdit(self)   
        self.motto.move(185, 210)  
        self.motto.setMaximumWidth(280)
        self.motto.setMinimumWidth(280)   
        self.motto.setFont(self.font)
        #����Ĭ��motto
        self.motto.setText(' Love a flower bloom to accompany it, love a man to accompany him to stray. ')

        self.img = QtGui.QLineEdit(self)   
        self.img.move(250, 270)   
        self.img.setMaximumWidth(215)
        self.img.setMinimumWidth(215)  
        self.img.setFont(self.font)

        self.labeltop = QtGui.QLabel(self)   
        self.labeltop.setFixedHeight(50)  
        #self.label.setAlignment(Qt.AlignCenter)  
        self.labeltop.setText("* file must be a photo with .jpg/.png/.gif/... in\nthe end of the name which acquires an English path.")
        self.labeltop.move(53, 310)  
        self.labeltop.setFont(self.font3)

        self.choose_img = QtGui.QPushButton('choose picture', self)   
        self.choose_img.move(80, 370)   
        self.choose_img.clicked.connect(self.choose_picture)
        self.choose_img.setFont(self.font)

        self.loginBtn = QtGui.QPushButton('Login', self)   
        self.loginBtn.move(330, 370)   
        self.loginBtn.clicked.connect(self.login)
        self.loginBtn.setFont(self.font)

        self.setMinimumSize(500,450) 

    #��¼��ת
    def login(self):   
        if connect_ok==0 :   
            QtGui.QMessageBox.critical(self, 'Error', "  Connection failed ! \n  Please restart the App.  ")  
        else:   
            if self.user.text()=='' or self.pwd.text()=='' or self.img.text()=='' :
                QtGui.QMessageBox.critical(self, 'Error', "  Username or Password or Profile Photo is empty!  ")
            else:
                # save img and return a uri from apache
                imguri = saveimg(self.img.text())
                if add_user(self.user.text(),self.pwd.text(),imguri,self.motto.text()):
                    new(str(self.user.text()))
                else:
                    QtGui.QMessageBox.critical(self, 'Error', "  Username already exists !  \n  Restart the App and Try another")

    #ͷ��ѡ��
    def choose_picture(self):
        filename = QtGui.QFileDialog.getOpenFileName(self, 'Open file','/home')
        self.img.setText(filename)

#�õ�β��
def getlast(s):
    temp = s.split('/')[-1]
    return temp

#����ͼƬ��·��
def saveimg(uri):
    uri = str(uri)
    fhead=struct.pack('128s11I',uri,0,0,0,0,0,0,0,0,os.stat(uri).st_size,0,0)
    sendSock.send(fhead)
    fp = open(uri,'rb')

    while 1:
        filedata = fp.read(BUFSIZE)
        if not filedata: 
            break
        sendSock.send(filedata)
    fp.close()
    return 'static/uploads/new_'+getlast(uri.strip('\00'))
'''

    print u"receiving......... \n",

    while 1:
        if restsize > BUFSIZE:
            filedata = sendSock.recv(BUFSIZE)
            #print len(filedata)
        else:
            filedata = sendSock.recv(restsize)
        if not filedata: 
            break
        #print '1'
        fp.write(filedata)
        restsize = restsize-len(filedata)
        if restsize == 0:
            break
    print u"receive over........\n"
    print '-------------------------------'
    fp.close()
'''


#socket����
HOST = '127.0.0.1'
PORT = 5000
PORT_FILE = 8000
ADDR =(HOST,PORT)
ADDR_FILE=(HOST,PORT_FILE)
BUFSIZE = 1024 # buffer
# create a new socket
sendSock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
FILEINFO_SIZE=struct.calcsize('128s32sI8s')
sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    try:
        #sock.connect(ADDR)
        sendSock.connect(ADDR_FILE)
        sendSock.settimeout(0.1)
        connect_ok = 1
    except Exception:
        connect_ok = 0
    login = Login()
    login.show()  
    pchat = PyqtChatApp('yangchaoqi')
    def new(myname):
        pchat.setName(myname)
        login.close()
        pchat.show()
        sock.connect(ADDR)
        sock.sendall(myname)
        sock.settimeout(0.1)

    sys.exit(app.exec_())
