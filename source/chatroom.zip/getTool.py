# -*- coding: cp936 -*-
import MySQLdb
import time
from random import Random
import random

#��ѯ�û����������
def check(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s' " %(name))
    cur.close()
    conn.commit()
    conn.close()
    return n

#����һ�����û�
def add_user(name,pwd,motto,img):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    if check(name) :
        cur.close()
        conn.commit()
        conn.close()
        return 0
    else:
        cur.execute("insert into name_pwd values('%s','%s','%s','%s','Undergraduate in SJTU','Mr.Box')" %(name,pwd,motto,img))
        cur.close()
        conn.commit()
        conn.close()
        return 1

#�����û��ĸ�����Ϣ
def updateProfile(name,nickname,profession,motto,image):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name='%s'" %(name))
    data = cur.fetchall()[0]
    pwd = data[1]
    cur.execute("delete from name_pwd where name='%s'" %(name))
    cur.execute("insert into name_pwd values('%s','%s','static/uploads/%s','%s','%s','%s')" %(name,pwd,image,motto,profession,nickname))
    cur.close()
    conn.commit()
    conn.close()

#������Ϣ
def sendMsg(receiver,sender,txt):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("insert into msg values('%s','%s','%s','%s','%s')" %(receiver,sender,txt,time.ctime(),time.time()))
    cur.close()
    conn.commit()
    conn.close()

#�ж��û����������
def if_name_exist(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s'" %(name))
    cur.close()
    conn.commit()
    conn.close()
    return n

#�õ��û��ĸ�����Ϣ
def showProfile(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name='%s'" %(name))
    try:
        data = cur.fetchall()[0]
        nickname = data[5]
        profession = data[4]
        motto = data[3]
        image_path = data[2]
        judge = 1
    except:
        nickname = ''
        profession = ''
        motto = ''
        image_path = ''
        judge = 0
    cur.close()
    conn.commit()
    conn.close()
    return nickname,profession,motto,image_path,judge

#���Ͷ�̬Ȧ
def sendmoment(name,nickname,mood,content,location):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("insert into activity_log values('%s','%s','%s','%s','%s','%s','%d')" %(name,nickname,content,time.ctime(),location,mood,time.time()))
    cur.close()
    conn.commit()
    conn.close()

#�ҵ�ͷ��img
def self_head(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name ='%s'"%(name))
    data = cur.fetchall()[0]
    cur.close()
    conn.commit()
    conn.close()
    return data[2]

#��ѯ���еĶ�̬
def get_activity():
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select name,nickname,log,time,location,mood from activity_log order by time2 desc")
    activity = cur.fetchall()
    
    cur.close()
    conn.commit()
    conn.close()
    return activity

#�ҵ������˵�������Ϣ��չ������ҳ��
def person(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select name,img,nickname,motto from name_pwd where name!='%s'"%(name))
    user_list = cur.fetchall()

    all_list1=[]
    for i in user_list:
        if i[0]!='group' and i[0]!='yangchaoqi':
            cur.execute("select * from username_address where name='%s'"%(i[0]))
            n = cur.fetchall()[0][3]
            if n==0:
                n='frontend'
            else:
                n='backend'
        elif i[0]!='yangchaoqi':
            n = 'backend'
        else:
            n = 'frontend'
        print i[0],n
        temp=[i[0],n,i[1],i[3],i[2],get_msg(name,i[0])]
        if len(temp[3])>20:
            temp[3] = temp[3][:20]
        all_list1.append(temp)
    cur.close()
    conn.commit()
    conn.close()
    return all_list1

#�õ������¼
def get_msg(name1,name2):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select message,time,time2 from msg where receiver='%s' and sender='%s'"%(name1,name2))
    data1 = cur.fetchall()
    cur.execute("select message,time,time2 from msg where receiver='%s' and sender='%s'"%(name2,name1))
    data2 = cur.fetchall()

    total_list=[]
    for item in data1:
        total_list.append(['left',get_img(name2),name2,item[0],item[1],item[2],''])
    for item in data2:
        total_list.append(['right',get_img(name1),name1,item[0],item[1],item[2],'speech-right'])
    total_list = sorted(total_list,key=lambda x:x[5])
    cur.close()
    conn.commit()
    conn.close()
    return total_list

#��ѯͷ��img
def get_img(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    # all user
    cur = conn.cursor()
    cur.execute("select img from name_pwd where name='%s'"%(name))
    n = cur.fetchall()[0][0]
    cur.close()
    conn.commit()
    conn.close()
    return n

#�ж��û����������
def name_exist(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s'"%(name))
    cur.close()
    conn.commit()
    conn.close()
    return n

#�ж�������ȷ��
def name_pwd(name,pwd):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    n = cur.execute("select * from name_pwd where name='%s' and pwd='%s'"%(name,pwd))
    cur.close()
    conn.commit()
    conn.close()
    return n

#�ҵ������û�
def find_user(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name !='%s' and name !='group' " %(name))
    data = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    list = []
    for item in data:
        conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
        cur = conn.cursor()
        n = cur.execute("select * from username_address where name ='%s' and status=1 " %(item[0]))
        cur.close()
        conn.commit()
        conn.close()
        if n==1:
            list.append(item)
    return list

#�����û���Ϣ
def update_user(name,time_span):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name !='%s' and name !='group' " %(name))
    data = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    list = []
    for item in data:
        conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
        cur = conn.cursor()
        n = cur.execute("select * from username_address where name ='%s' and status=1 and time>'%s' " %(item[0],time_span))
        cur.close()
        conn.commit()
        conn.close()
        if n==1:
            list.append(item)
        conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
        cur = conn.cursor()
        cur.execute("select max(time) from username_address where status=1")
        t = cur.fetchall()[0][0]
        cur.close()
        conn.commit()
        conn.close()
    return list,t

#�ҵ�Ⱥ
def find_group(name):
    conn= MySQLdb.connect(
        host='localhost',
        user='root',
        db ='ss',
        charset='utf8'
        )
    cur = conn.cursor()
    cur.execute("select * from name_pwd where name ='group'")
    data = cur.fetchall()
    cur.close()
    conn.commit()
    conn.close()
    return data
