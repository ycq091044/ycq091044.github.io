### 环境配置：
- Python2.7.13
- 库：os、PyQt4、time、socket、struct、math、webbrowser、PIL、Image 、MySQLdb、threading、socketserver、flask、hashlib、random、urllib2、re、bs4、BeautifulSoup
- 服务器数据库：（字符串类型设为长度500，整数类型设为长度100）
- activity_log：name（字符串类型）、nickname（字符串类型）、log（字符串类型）、time（字符串类型）、location（字符串类型）、mood（字符串类型）、time2（整数类型）
- msg：receiver（字符串类型）、sender（字符串类型）、message（字符串类型）、time（字符串类型）、time2（整数类型）
- name_pwd：name（字符串类型）、pwd（字符串类型）、img（字符串类型）、motto（字符串类型）、profession（字符串类型）、nickname（字符串类型）
- username_address ：name（字符串类型）、address（字符串类型）、pid（字符串类型）、status（整数类型）、time（字符串类型）

### 启动：
- 打开服务器数据库（此时在name_pwd表中需先插入用户名为“yangchaoqi”、“group”两个默认用户）,双击运行server_file.exe、server_msg.exe
- 双击运行两个客户端hacDemo1.exe、hacDemo2.exe、hacDemo3.exe（文件分别传输到upload、upload2、upload3）
- 安装virtualenv，打开cmd，在文件夹目录下输入：virtualenv p3vir，打开python虚拟环境，自动出现venv文件夹
- 双击开启服务器：server_moment.py（其中一个库的缘故，无法打包成exe）
- 双击运行getDouban.exe（或getDouban.py）爬取数据，双击运行generateActivityLog.exe随机生成动态，双击运行generateMsg.exe随机生成聊天记录
- 此时可打开动态圈

### 说明：
- 这里的exe文件由于过大，没有上传GitHub，但都是可以通过py文件编译生成的，如果大家有需要的话，请联系杨超琪ycqsjtu@gmail.com or never_say_never@sjtu.edu.cn
