# -*- coding: cp936 -*-
import sys
from PyQt4 import QtGui
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from getTool import find_user,find_group

#�Զ����û��б�
class QCustomQWidget (QtGui.QWidget):
    #��̳�
    def __init__ (self, parent = None):
        super(QCustomQWidget, self).__init__(parent)

        #��������
        self.textQVBoxLayout = QtGui.QVBoxLayout()
        self.textUpQLabel    = QtGui.QLabel()
        self.textDownQLabel  = QtGui.QLabel()
        self.textQVBoxLayout.addWidget(self.textUpQLabel)
        self.textQVBoxLayout.addWidget(self.textDownQLabel)
        self.allQHBoxLayout  = QtGui.QHBoxLayout()
        self.iconQLabel      = QtGui.QLabel()
        self.allQHBoxLayout.addWidget(self.iconQLabel, 0)
        self.allQHBoxLayout.addLayout(self.textQVBoxLayout, 1)
        self.setLayout(self.allQHBoxLayout)
        # setStyleSheet
        self.textUpQLabel.setStyleSheet('''
            color: rgb(0, 0, 255);
        ''')
        self.textDownQLabel.setStyleSheet('''
            color: rgb(255, 127, 0);
        ''')
        #font
        self.font1 = QFont()
        self.font1.setFamily('Consolas')
        self.font1.setFixedPitch(True)
        self.font1.setPointSize(12)
        self.font1.setBold(False)

        #font2
        self.font2 = QFont()
        self.font2.setFamily('Consolas')
        self.font2.setFixedPitch(True)
        self.font2.setPointSize(10)
        self.font2.setBold(False)
        

    def setTextUp (self, text):
        self.textUpQLabel.setText(text)
        self.textUpQLabel.setFont(self.font1)
    def setTextDown (self, text):
        self.textDownQLabel.setText(text)
        self.textDownQLabel.setFont(self.font2)
    def setIcon (self, imagePath):
        self.iconQLabel.setPixmap(QtGui.QPixmap(imagePath))

#�û��б���
class UserList (QtGui.QMainWindow):
    list=[]
    def __init__ (self,nickname):
        super(UserList, self).__init__()
        # Create QListWidget
        self.myQListWidget = QtGui.QListWidget(self)
        #self.myQListWidget.itemDoubleClicked.connect(self.insert)
        self.setCentralWidget(self.myQListWidget)
        self.name = nickname
        self.update()
    @pyqtSlot(QListWidgetItem)
    def query(self,item):
        for i in range(len(self.list)):
            if self.list[i]=="%s"%item :
                all_user = find_user(self.name)
                return all_user[i][0],all_user[i][3],all_user[i][2]

    def addUser(self,name,motto,img):
        self.myQCustomQWidget = QCustomQWidget()
            
        self.myQCustomQWidget.setTextUp(name)
        self.myQCustomQWidget.setTextDown(motto)
        self.myQCustomQWidget.setIcon(img)
        # Create QListWidgetItem
        myQListWidgetItem = QtGui.QListWidgetItem(self.myQListWidget)
        self.list.append('%s'%myQListWidgetItem)
        # Set size hint
        myQListWidgetItem.setSizeHint(self.myQCustomQWidget.sizeHint())
        # Add QListWidgetItem into QListWidget
        self.myQListWidget.addItem(myQListWidgetItem)
        self.myQListWidget.setItemWidget(myQListWidgetItem, self.myQCustomQWidget)

    #�ҵ������û�������
    def update(self):
        self.list=[]
        self.myQListWidget.clear()
        all_user = find_user(self.name)
        for i in all_user:
            self.addUser(i[0],i[3],i[2])

#Ⱥ�б���
class GroupList (QtGui.QMainWindow):
    def __init__ (self,nickname):
        super(GroupList, self).__init__()
        # Create QListWidget
        self.myQListWidget = QtGui.QListWidget(self)
        #self.myQListWidget.itemDoubleClicked.connect(self.insert)
        self.setCentralWidget(self.myQListWidget)
        self.name = nickname
        self.find_others()
    @pyqtSlot(QListWidgetItem)
    def query(self,item):
        all_user = find_group(self.name)[0]
        return  all_user[0],all_user[3],all_user[2]

    def addUser(self,name,motto,img):
        self.myQCustomQWidget = QCustomQWidget()
            
        self.myQCustomQWidget.setTextUp(name)
        self.myQCustomQWidget.setTextDown(motto)
        self.myQCustomQWidget.setIcon(img)
        # Create QListWidgetItem
        myQListWidgetItem = QtGui.QListWidgetItem(self.myQListWidget)
        # Set size hint
        myQListWidgetItem.setSizeHint(self.myQCustomQWidget.sizeHint())
        # Add QListWidgetItem into QListWidget
        self.myQListWidget.addItem(myQListWidgetItem)
        self.myQListWidget.setItemWidget(myQListWidgetItem, self.myQCustomQWidget)

    #�ҵ�����Ⱥ������
    def find_others(self):
        all_user = find_group(self.name)
        for i in all_user:
            print i
            self.addUser(i[0],i[3],i[2])


if __name__=='__main__':
    app = QtGui.QApplication([])
    window = GroupList('2')
    window.setMinimumSize(200,500)
    window.show()
    sys.exit(app.exec_())
