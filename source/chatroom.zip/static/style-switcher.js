#!/bin/env python
# _*_coding:utf-8_*_
import os
from flask import Flask,render_template
from flask import request
import MySQLdb
from check_register import add_user
from check_login import name_exist,name_pwd

app = Flask(__name__)
@app.route('/', methods=['GET'])
def index():
	return render_template('index.html')


@app.route('/register/', methods=['POST'])
def register():
    name_reg=request.form['name_reg']
    pwd_reg=request.form['pwd_reg']
    pwd2_reg=request.form['pwd2_reg']
    mail_reg=request.form['mail_reg']
    if pwd_reg==pwd2_reg :
    	add_user(name_reg,pwd_reg,mail_reg)$(document).ready(function() {
    
    /* ======= DEMO THEME CONFIG ====== */
    $('#config-trigger').click(function(e){
        
        e.preventDefault();
        
        //$("#config-panel").toggleClass('config-panel-open');
        
        if($(this).hasClass('config-panel-open')){
          $("#config-panel").animate({
            right: "-=190" //same as the panel width
           }, 500);
          $(this).removeClass('config-panel-open').addClass('config-panel-hide');
         }
         else {      
         $("#config-panel").animate({
           right: "+=190" //same as the panel width
           }, 500);
          $(this).removeClass('config-panel-hide').addClass('config-panel-open');    
         }
    });
    
    $('#config-close').on('click', function(e) {
        e.preventDefault();
        $('#config-trigger').click();
    });
    
    
    $('#color-options a').on('click', function(e) { 
        var $styleSheet = $(this).attr('data-style');
        var $chartColor = $(this).attr('data-chart');
        
        $('#theme-style').attr('href', $styleSheet);
                
        var $listItem = $(this).closest('li');
        $listItem.addClass('active');
        $listItem.siblings().removeClass('active');
        
        e.preventDefault();
        
        // On click destory the current pie chart
        $('.chart').data('easy-pie-chart', null);
        
        //Create a new pie chart with a new colour
        $('.chart').easyPieChart({      
            barColor: $chartColor,
            trackColor: '#e8e8e8',
            scaleColor: false,
            lineWidth : 5,
            animate: 2000,
            onStep: function(from, to, percent) {
                $(this.el).find('span').text(Math.round(percent));
            }
        }); 
        
    });


});
    	return 'next'
    else:
    	return render_template('index.html')

@app.route('/login/', methods=['POST'])
def login():
    name_login=request.form['name_login']
    pwd_login=request.form['pwd_login']
    if name_exist(name_login):
    	if name_pwd(name_login,pwd_login):
    		return 'next'
    	else:
    		return render_template('index.html',tips='the password is incorrect!')
    else:
    	return render_template('index.html',tips='name is not exists!')

if __name__ == '__main__':
    app.run(host='127.0.0.1',port=5000,debug=True)
